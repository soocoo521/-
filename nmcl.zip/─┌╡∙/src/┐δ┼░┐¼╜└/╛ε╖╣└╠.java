package 용키연습;

import java.util.ArrayList;
import java.util.Random;

public class 어레이 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(2);
		list.add(4);
		list.add(8);
		
		Random rand = new Random();
		
		int asdf = 1;
		for(int i = 0; i < list.size(); i++) asdf *= list.get(i);
		int a = rand.nextInt(asdf) + 1;
		
		int x = 0;
		boolean no = true;
		if(x < a && a <= x + asdf / list.get(0)) {
			System.out.print(2);
			no = false;
		}
		x += asdf / list.get(0);
		if(x < a && a <= x + asdf / list.get(1)) {
			System.out.print(4);
			no = false;
		}
		x += asdf / list.get(1);
		if(x < a && a <= x + asdf / list.get(2)) {
			System.out.print(8);
			no = false;
		}
		
		if(no == true) System.out.print(0);
		
	}

}
