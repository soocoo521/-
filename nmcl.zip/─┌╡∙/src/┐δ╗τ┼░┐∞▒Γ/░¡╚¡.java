package 용사키우기;

public interface 강화 {
	
	public void 레벨업();
	public void 특훈();
	public void 훈련();
	public void 룬();

}
