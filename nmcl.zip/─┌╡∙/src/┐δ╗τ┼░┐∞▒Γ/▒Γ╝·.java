package 용사키우기;

public interface 기술 {
	
	public int 찌르기(String name);
	public int 검술(String name);
	public int 가르기(String name);

}
