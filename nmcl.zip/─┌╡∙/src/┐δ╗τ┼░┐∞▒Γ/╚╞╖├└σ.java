package 용사키우기;

public interface 훈련장 {
	
	public void 근력훈련();
	public void 체력훈련();
	public void 자세훈련();

}
