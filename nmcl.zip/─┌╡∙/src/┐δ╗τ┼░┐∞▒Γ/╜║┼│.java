package 용사키우기;

public interface 스킬 {
	
	public void 찌르기(String 적); //공 * 1.25~2 쿨 짧
	public void 붕대감기();  //체력 10~30% 쿨 짧
	public void 집중(); //공격력 * 1.25~1.5 쿨 짧
	public void 난격(String 적); //공 * 1.1~1.3 쿨 중 *5~7
	public void 검무(String 적); //공 * 1.1~1.4 쿨 중상 *6~8
	public void 진공가르기(String 적); //공 * 1.75~3 쿨 중~상상
	public void 준비자세(); //공격력 * 1.75~2.5 쿨 짧중~상 다음턴 공격만 썌짐
	public void 환영찌르기(String 적); //공 2~2.75 쿨 짧중~중상 30~70퍼 치명적인 공격
	public void 연속베기(String 적); //공 1.45~1.7 쿨 중 *2~3
	public void 처형(String 적); //공 1 쿨 상 상대 hp보고 공 4
	public void 조잡한검술(String 적); //공 1.3 ~ 1.6 쿨 중 *4~5
	public void 물아일체(); //체력 80~100% 쿨 상~상상
	
}
