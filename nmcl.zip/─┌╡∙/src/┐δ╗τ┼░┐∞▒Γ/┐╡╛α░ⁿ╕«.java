package 용사키우기;

public interface 영약관리 {
	
	public void 영약흡수1(영약 _영약);
	public void 영약흡수2(영약 _영약);
	public void 영약흡수3(영약 _영약);

}
