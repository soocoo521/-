package 용사키우기;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class 용사 extends 능력치 implements 밤,훈련장 {
	
	private Scanner sc = new Scanner(System.in);
	
	private String 무기;
	private String 인벤토리[];
	private int 지갑;
	private int 근, 체, 자;

	public 용사() {
		인벤토리 = new String[11];
		지갑 = 0;
		근 = 1;
		체 = 1;
		자 = 1;
	}
	
	public int get지갑() {
		return 지갑;
	}
	
	public String get인벤토리(int 인벤토리) {
		return this.인벤토리[인벤토리];
	}
	
	public String get무기() {
		return 무기;
	}

	public void set지갑(int 지갑) {
		this.지갑 = 지갑;
	}
	
	public void set인벤토리(int 인벤토리, String 아이템) {
		this.인벤토리[인벤토리] = 아이템;
	}
	
	public void set무기(String 무기) {
		this.무기 = 무기;
	}

	public void 근력훈련() {
		int nit = 근 * 500 + get공격력() * 7;
		System.out.print("근력훈련을 하기 위해 " + nit + "니트가 필요합니다.\n훈련하시겠습니까? ");
		String answer = sc.nextLine();
		if(answer.equals("d")) {
			if(지갑 < nit) System.out.println("돈이 부족하다네");
			else {
				지갑 -= nit;
				set공격력(get공격력() + 1);
				System.out.println("공격력이 " + get공격력() + "로 향상됬다.");
			}
		}
	}
	
	public void 체력훈련() {
		int nit = 체 * 500 + get최대체력() * 7;
		System.out.print("체력훈련을 하기 위해 " + nit + "니트가 필요합니다.\n훈련하시겠습니까? ");
		String answer = sc.nextLine();
		if(answer.equals("d")) {
			if(지갑 < nit) System.out.println("돈이 부족하다네.");
			else {
				지갑 -= nit;
				set최대체력(get최대체력() + 1);
				System.out.println("체력이 " + get최대체력() + "로 향상됬다.");
			}
		}
	}
	
	public void 자세훈련() {
		if(get크리확률() == 100) System.out.println("이미 자세가 정확하다.");
		else {
			int nit = 자 * 500 + get크리확률() * 3;
			System.out.print("자세훈련을 하기 위해 " + nit + "니트가 필요합니다.\n훈련하시겠습니까? ");
			String answer = sc.nextLine();
			if(answer.equals("d")) {
				if(지갑 < nit) System.out.println("돈이 부족하다네.");
				else {
					지갑 -= nit;
					set크리확률(get크리확률() + 1);
					System.out.println("자세 정확도가 " + get크리확률() + "로 향상됬다.");
				}
			}
		}
	}
	
	private int 확률() {
		Random rand = new Random();
        ArrayList<Integer> array = new ArrayList<>();

		array.add(2);
		array.add(4);
		array.add(8);
		array.add(16);
		array.add(32);
		array.add(64);
		array.add(128);	
		array.add(256);
		array.add(777);
		array.add(1024);
		array.add(2048);
		array.add(4096);
		array.add(8192);
		array.add(10000);
		array.add(16384);
		array.add(32768);
		array.add(65536);
		array.add(100000);
		array.add(131072);
		array.add(262144);
		array.add(524288);
		array.add(1000000);
		array.add(100000000);

		int a = 10;
		
		while((array.get(array.size() - 1) - a) > 0) a *= 10;

		int b = rand.nextInt(a) + 1;
		int stack = 0;
		int c = 0;

		for (int i = 0; i < array.size(); i++) {
			stack += a / array.get(i);
			if (stack - a / array.get(i) < b && b < stack) c = array.get(i);
		}

		return c;
	}
	
	public void 명상() {
		int a = 확률();
		if(a == 0) System.out.println("잠을 자버렸다.");
		else {
			set집중력(get집중력() + a);
			System.out.println("집중력이 " + a + "만큼 상승했다.");
		}
	}
	
	public void 고찰() {
		int a = 확률();
		if(a == 0) System.out.println("잠을 자버렸다.");
		else {
			set정신력(get정신력() + a);
			System.out.println("정신력이 " + a + "만큼 상승했다.");
		}
	}
	
	public void 전략분석() {
		int a = 확률();
		if(a == 0) System.out.println("잠을 자버렸다.");
		else {
			set전략(get전략() + a);
			System.out.println("전략이 " + a + "만큼 상승했다.");
		}
	}

}
