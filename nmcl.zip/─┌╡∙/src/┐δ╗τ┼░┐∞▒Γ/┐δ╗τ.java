package 용사키우기;

public class 용사 extends 능력치 implements 강화,스킬 {

}
