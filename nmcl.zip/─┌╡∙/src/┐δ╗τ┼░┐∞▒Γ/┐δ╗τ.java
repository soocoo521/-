package 용사키우기;

import java.util.Random;

public class 용사 extends 모험 implements 영약관리,기술 {
	
	private Random rand = new Random();
	private int 공격력;
	private int 체력;
	private String[] 영약최대치 = new String[9];
	private 영약[] 인벤토리 = new 영약[20];
	
	public 용사() {
		공격력 = rand.nextInt(35) + 80;
		체력 = rand.nextInt(35) + 80;
	}
	
	public int 찌르기(String name) {
		int ad = 210 + 공격력;
		System.out.println("용사는 찌르기를 시전했다.");
		System.out.println("용사가 " + name + "에게 " + ad + "의 피해를 입혔다.");
		return ad;
	}
	
	public int 검술(String name) {
		int ad = (int)(공격력 + 50 * 1.75);
		System.out.println("용사는 검술을 시전했다.");
		System.out.println("용사가 " + name + "에게 " + ad + "의 피해를 입혔다.");
		return ad;
	}
	
	public int 가르기(String name) {
		int ad = (공격력 + 300 * 4);
		System.out.println("용사는 가르기를 시전했다.");
		System.out.println("용사가 " + name + "에게 " + ad + "의 피해를 입혔다.");
		return ad;
	}

	public void 영약흡수1(영약 _영약) {
		공격력 += _영약.get능력치();
	}
	
	public void 영약흡수2(영약 _영약) {
		체력 += _영약.get능력치();
	}
	
	public void 영약흡수3(영약 _영약) {
		
	}

}
