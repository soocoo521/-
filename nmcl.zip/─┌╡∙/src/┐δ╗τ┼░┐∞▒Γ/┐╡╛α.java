package 용사키우기;

public class 영약 {
	
	private String 이름;
	private int 능력치;
	
	public 영약(String 이름) {
		this.이름 = 이름;
	}

	public String get이름() {
		return 이름;
	}

	public int get능력치() {
		return 능력치;
	}

	public void set이름(String 이름) {
		this.이름 = 이름;
	}

	public void set능력치(int 능력치) {
		this.능력치 = 능력치;
	}
	
}
