package 용사키우기;

import java.util.Random;

public abstract class 능력치 {
	
	private Random rand = new Random();

	private int 공격력;
	private int 최대체력;
	private int 현재체력;
	private int 크리확률;
	private int 정신력;
	private int 집중력;
	private int 전략;
	
	public 능력치() {
		공격력 = rand.nextInt(46) + 80;
		최대체력 = rand.nextInt(46) + 80;
		현재체력 = 최대체력;
		크리확률 = 20;
		정신력 = 10;
		집중력 = 80;
		전략 = 100;
	}

	public int get공격력() {
		return 공격력;
	}

	public int get최대체력() {
		return 최대체력;
	}

	public int get현재체력() {
		return 현재체력;
	}
	
	public int get크리확률() {
		return 크리확률;
	}

	public int get정신력() {
		return 정신력;
	}

	public int get집중력() {
		return 집중력;
	}

	public int get전략() {
		return 전략;
	}

	public void set공격력(int 공격력) {
		this.공격력 = 공격력;
	}

	public void set최대체력(int 최대체력) {
		this.최대체력 = 최대체력;
	}

	public void set현재체력(int 현재체력) {
		this.현재체력 = 현재체력;
		if((this.현재체력 + 현재체력) > 최대체력) this.현재체력 = 최대체력;
	}
	
	public void set크리확률(int 크리확률) {
		this.크리확률 = 크리확률;
	}

	public void set정신력(int 정신력) {
		this.정신력 = 정신력;
	}

	public void set집중력(int 집중력) {
		this.집중력 = 집중력;
	}

	public void set전략(int 전략) {
		this.전략 = 전략;
	}

}
