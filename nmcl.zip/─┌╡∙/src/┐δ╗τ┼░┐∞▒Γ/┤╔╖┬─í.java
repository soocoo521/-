package 용사키우기;

import java.util.Random;

public abstract class 능력치 {
	
	private Random rand = new Random();
	private int 공격력;
	private int 체력;
	
	public 능력치() {
		공격력 = rand.nextInt(35) + 80;
		체력 = rand.nextInt(35) + 80;
	}

}
