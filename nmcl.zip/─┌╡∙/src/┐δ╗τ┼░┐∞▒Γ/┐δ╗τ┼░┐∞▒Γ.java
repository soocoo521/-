package 용사키우기;

import java.util.Random;
import java.util.Scanner;

public class 용사키우기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		용사키우기 game1 = new 용사키우기();
		game1.start();
	}
	
	public void start() {
		Random rand = new Random();
		Scanner sc = new Scanner(System.in);
		용사 플레이어 = new 용사();
		
		int 땅 = 0;
		String 위치 = "마을";
		int 이동 = 11;
		int 시간 = 0;
		int day = 50;
		boolean homeflag = false;
		
		int 숫자입력;
		String 문자입력;
		
		while(true) {
			if (시간 > 23) 시간 = 시간 - 24;
			if(땅 == 0) {
				System.out.print(위치 + " (");
				if(7 < 시간 && 시간 < 20) System.out.print("낮");
				else if(시간 <= 7 || 시간 >= 20) System.out.print("밤");
				System.out.print(")\n1.휴식\n2.이동\n☞");
				숫자입력 = sc.nextInt();
				sc.nextLine();
				System.out.println();
				
				if(숫자입력 == 1) {
					플레이어.set현재체력(플레이어.get현재체력() + (int)(플레이어.get최대체력() * 0.1));
					시간 += rand.nextInt(2) + 1;
					System.out.println(">휴식>\n체력이 약간 회복됬다.\n");
				}
				else if(숫자입력 == 2) {
					System.out.println(">이동>");
					while(true) {
						for(int y = 5; y > 0; y--) {
							for(int x = 1; x < 6; x++) {
								if(x == (이동 % 5) && y == (이동 / 5)) {
									System.out.print("×");
									if(x == 2 && y == 5) 위치 = "대장간";
									else if(x == 5 && y == 4) 위치 = "선착장";
									else if(x == 1 && y == 3) 위치 = "훈련장";
									else if(x == 3 && y == 3) 위치 = "시계탑";
									else if(x == 4 && y == 2 && homeflag == true) 위치 = "집";
									else if(x == 2 && y == 1) 위치 = "선착장";
									else 위치 = "마을";
								}
								else if(x == 2 && y == 5) System.out.print("■");
								else if(x == 5 && y == 4) System.out.print("■");
								else if(x == 1 && y == 3) System.out.print("■");
								else if(x == 3 && y == 3) System.out.print("■");
								else if(x == 4 && y == 2 && homeflag == true) System.out.print("■");
								else if(x == 2 && y == 1) System.out.print("■");
								else System.out.print("□");
							}
							System.out.println(); //지도 옆에 전 좌 우 후 순으로 배치 전 옆에는 멈춤 배치하고 손가락은 지도 밑에
						}
						System.out.print("1.전\n2.좌\n3.우\n4.후5.멈춤\n☞");
						숫자입력 = sc.nextInt();
						sc.nextLine();
						if(숫자입력 == 1 && 이동 > 5) 이동 -= 5;
						else if(숫자입력 == 2 && 이동 % 5 > 1) 이동 -= 1;
						else if(숫자입력 == 3 && 이동 % 5 < 5 && 이동 % 5 != 0) 이동 += 1;
						else if(숫자입력 == 4 && 이동 < 21) 이동 += 5;
						else if(숫자입력 == 5) break;
					}
					System.out.println();
				}
			}
			else if(땅 == 1) {
				
			}
		}
	}
}

//집
//대장간
//선착장
//시계탑
//훈련장

//선착장
//길드
//여관
//시계탑