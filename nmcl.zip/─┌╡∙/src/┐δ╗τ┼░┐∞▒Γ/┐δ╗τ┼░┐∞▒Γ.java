package 용사키우기;

public class 용사키우기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
