package 용사키우기;

public interface 밤 {
	
	public void 명상();
	public void 고찰();
	public void 전략분석();

}
