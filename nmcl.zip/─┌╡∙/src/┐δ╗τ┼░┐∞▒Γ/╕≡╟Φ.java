package 용사키우기;

public abstract class 모험 {

}
